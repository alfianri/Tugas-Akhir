[![Tex](https://github.com/josestg/Latex-TA-IF-ITERA/actions/workflows/tex.yml/badge.svg)](https://github.com/josestg/Latex-TA-IF-ITERA/actions/workflows/tex.yml)

# Latex-TA-IF-ITERA
Template Latex Tugas Akhir untuk Program Studi Teknik Informatika, ITERA

Oleh Tim Dosen Prodi Teknik Informatika ITERA

Berdasarkan "Templat LaTeX Tesis Informatika ITB" oleh Petra Barus & Peb Ruswono Aryan

https://github.com/petrabarus/if-itb-latex
